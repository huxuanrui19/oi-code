#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=5e3+10;
const ll mod=1e9+7;
string a,b;
int n,m,dp[N][N];
int main(){
	freopen("lcs.in","r",stdin);
	freopen("lcs.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
	cin>>a>>b;
	n=a.size();
	m=b.size();
	a=' '+a;
	b='&'+b;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			if(a[i]==b[j]){
				dp[i][j]=dp[i-1][j-1]+1;
			}
			else{
				dp[i][j]=max(dp[i][j-1],dp[i-1][j]);
			}
		}
	}
	int maxn=0;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			maxn=max(maxn,dp[i][j]);
		}
	}
	cout<<maxn<<"\n1";
	return 0;
}

