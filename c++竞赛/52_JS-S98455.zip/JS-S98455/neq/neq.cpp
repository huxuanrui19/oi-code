#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=3e3+10;
int n,q,a[N];
int main(){
	freopen("neq.in","r",stdin);
	freopen("neq.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	cin>>n>>q;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	while(q--){
		int l,r;
		cin>>l>>r;
		cout<<"0\n";
	}
	return 0;
}

