#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e5+10;

int main(){
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	int n,q;
	cin>>n>>q;
	while(q--){
		string a,b;
		cin>>a>>b;
		if(n==1){
			if(a==b) cout<<"0\n";
			else cout<<min(abs(a[0]-b[0]),10-abs(a[0]-b[0]))<<"\n";
		}
		else if(n==2){
			if(a==b) cout<<"0\n";
			else{
				int x1=abs(a[1]-b[1]);
				int x2=abs(a[0]-b[0]);
				int ans=min({x1+x2,x1+10-x2,10-x1+x2,10-x1+10-x2});
				int x=a[0]-'0',y=a[1]-'0';
				for(int i=0;i<=10;i++){
					x1=abs(y-b[1]+'0'),x2=abs(x-b[0]+'0');
					int cnt=min({x1+x2,x1+10-x2,10-x1+x2,10-x1+10-x2});
					ans=min(ans,cnt+i);
					y=(y+1)%10;
					x=(x+1)%10;
				}
				x=a[0]-'0',y=a[1]-'0';
				for(int i=0;i<=10;i++){
					x1=abs(y-b[1]+'0'),x2=abs(x-b[0]+'0');
					int cnt=min({x1+x2,x1+10-x2,10-x1+x2,10-x1+10-x2});
					ans=min(ans,cnt+i);
					y=(y-1+10)%10;
					x=(x-1+10)%10;
				}
				cout<<ans<<"\n";
			}
		}
		else{
			cout<<"0\n";
		}
	}
	return 0;
}

